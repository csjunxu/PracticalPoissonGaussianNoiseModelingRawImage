function [raw_array]=rawimread_fuji_tiff(tiff_filename,channels)
% Extracts color components in rectangular form from SuperCCD RAW (45-degrees tilted)   
% Currently configured for S5200/S5600/S9100/S9600 only!!
% [ simple but slowish; requires memory ]
% 
%    function [raw_array]=rawimread_fuji_tiff(tiff_filename,channels)
%
%  INPUT:
%      tiff_filename    filename of the 16-bit TIFF image  (which can be obtained from .RAF files using DCRAW, with the options  -D -4 -T -j -v )
%      channels         a vector with the channels to be extracted. E.g., [1 2 3], where 1=red, 2=green, 3=blue  (can be also a singleton)
%
%
%  OUTPUT:
%      raw_array        cell-array with the extracted channels  (if channels is singleton, the cell-array is replaced simply by the matrix of the specified channel)
%
%

raw45=imread(tiff_filename);

if numel(raw45)==10442592  %%% S5600
    raw45=[raw45;uint16(zeros(1,3232))];

    if max(channels==2)
        %G
        [XMATRIX,YMATRIX]=meshgrid(1:uint16(size(raw45,1)),1:uint16(size(raw45,2)));
        zigzags=repmat(uint16([1 0;0 1]),[1616 1616]).*(XMATRIX+YMATRIX).*uint16((((XMATRIX+YMATRIX)>1844)&((XMATRIX+YMATRIX)<(3232+1388+1)))&(((32768-XMATRIX+YMATRIX)>(32768-1844-1))&((32768-XMATRIX+YMATRIX)<(32768+3232-1388))));
        zigzags=sortrows([[1:numel(XMATRIX)]',uint32(zigzags(:))],2);
        clear XMATRIX YMATRIX
        zigzags=zigzags(find(zigzags(:,2)),1);
        raw_g=raw45(zigzags(:));
        clear zigzags;
        raw_g=(reshape(raw_g([1:1388*922*2]),[922*2 1388])');
    end

    if max(channels==3)
        %B
        raw45_b=raw45(1:2:end,2:2:end);
        [XMATRIX,YMATRIX]=meshgrid(1:uint16(size(raw45_b,1)),1:uint16(size(raw45_b,2)));
        zigzags=(XMATRIX+YMATRIX).*uint16((((XMATRIX+YMATRIX)>1844/2)&((XMATRIX+YMATRIX)<(3232/2+1388/2+1)))&(((32768-XMATRIX+YMATRIX)>(32768-1844/2-1))&((32768-XMATRIX+YMATRIX)<(32768+3232/2-1388/2))));
        zigzags=sortrows([[1:numel(XMATRIX)]',uint32(zigzags(:))],2);
        clear XMATRIX YMATRIX
        zigzags=zigzags(find(zigzags(:,2)),1);
        raw_b=raw45_b(zigzags(:,1));
        clear zigzags raw45_b
        raw_b=reshape(raw_b([1:1388*922]),[922 1388])';
    end

    if max(channels==1)
        %R
        raw45_r=raw45(2:2:end,1:2:end-1);
        [XMATRIX,YMATRIX]=meshgrid(1:uint16(size(raw45_r,1)),1:uint16(size(raw45_r,2)));
        zigzags=(XMATRIX+YMATRIX).*uint16((((XMATRIX+YMATRIX)>1844/2)&((XMATRIX+YMATRIX)<(3232/2+1388/2+1)))&(((32768-XMATRIX+YMATRIX)>(32768-1844/2-1))&((32768-XMATRIX+YMATRIX)<(32768+3232/2-1388/2))));
        zigzags=sortrows([[1:numel(XMATRIX)]',uint32(zigzags(:))],2);
        clear XMATRIX YMATRIX
        zigzags=zigzags(find(zigzags(:,2)),1);
        raw_r=raw45_r(zigzags(:,1));
        clear zigzags raw45_r
        raw_r=reshape(raw_r([1:1388*922]),[922 1388])';
    end

    if numel(channels)>1   %% CREATE CELL
        counter=0;
        if max(channels==1)
            counter=counter+1;
            raw_array{counter}=raw_r;
        end
        if max(channels==2)
            counter=counter+1;
            raw_array{counter}=raw_g;
        end
        if max(channels==3)
            counter=counter+1;
            raw_array{counter}=raw_b;
        end
    else
        if max(channels==1)
            raw_array=raw_r;
        end
        if max(channels==2)
            raw_array=raw_g;
        end
        if max(channels==3)
            raw_array=raw_b;
        end

    end


elseif  numel(raw45)==18416972   %% S9600

    raw45=[raw45;uint16(zeros(1,4292))];

    if max(channels==2)
        %G
        [XMATRIX,YMATRIX]=meshgrid(1:uint16(size(raw45,1)),1:uint16(size(raw45,2)));
        zigzags=repmat(uint16([1 0;0 1]),[2146 2146]).*(XMATRIX+YMATRIX).*uint16((((XMATRIX+YMATRIX)>2448)&((XMATRIX+YMATRIX)<(4292+1844+1)))&(((32768-XMATRIX+YMATRIX)>(32768-2448-1))&((32768-XMATRIX+YMATRIX)<(32768+4292-1844))));
        zigzags=sortrows([[1:numel(XMATRIX)]',uint32(zigzags(:))],2);
        clear XMATRIX YMATRIX
        zigzags=zigzags(find(zigzags(:,2)),1);
        raw_g=raw45(zigzags(:));
        clear zigzags;
        raw_g=(reshape(raw_g([1:1844*1224*2]),[1224*2 1844])');
    end

    if max(channels==3)
        %B
        raw45_b=raw45(1:2:end,2:2:end);
        [XMATRIX,YMATRIX]=meshgrid(1:uint16(size(raw45_b,1)),1:uint16(size(raw45_b,2)));
        zigzags=(XMATRIX+YMATRIX).*uint16((((XMATRIX+YMATRIX)>2448/2)&((XMATRIX+YMATRIX)<(4292/2+1844/2+1)))&(((32768-XMATRIX+YMATRIX)>(32768-2448/2-1))&((32768-XMATRIX+YMATRIX)<(32768+4292/2-1844/2))));
        zigzags=sortrows([[1:numel(XMATRIX)]',uint32(zigzags(:))],2);
        clear XMATRIX YMATRIX
        zigzags=zigzags(find(zigzags(:,2)),1);
        raw_b=raw45_b(zigzags(:,1));
        clear zigzags raw45_b
        raw_b=reshape(raw_b([1:1844*1224]),[1224 1844])';
    end

    if max(channels==1)
        %R
        raw45_r=raw45(2:2:end,1:2:end-1);
        [XMATRIX,YMATRIX]=meshgrid(1:uint16(size(raw45_r,1)),1:uint16(size(raw45_r,2)));
        zigzags=(XMATRIX+YMATRIX).*uint16((((XMATRIX+YMATRIX)>2448/2)&((XMATRIX+YMATRIX)<(4292/2+1844/2+1)))&(((32768-XMATRIX+YMATRIX)>(32768-2448/2-1))&((32768-XMATRIX+YMATRIX)<(32768+4292/2-1844/2))));
        zigzags=sortrows([[1:numel(XMATRIX)]',uint32(zigzags(:))],2);
        clear XMATRIX YMATRIX
        zigzags=zigzags(find(zigzags(:,2)),1);
        raw_r=raw45_r(zigzags(:,1));
        clear zigzags raw45_r
        raw_r=reshape(raw_r([1:1844*1224]),[1224 1844])';
    end

    if numel(channels)>1   %% CREATE CELL
        counter=0;
        if max(channels==1)
            counter=counter+1;
            raw_array{counter}=raw_r;
        end
        if max(channels==2)
            counter=counter+1;
            raw_array{counter}=raw_g;
        end
        if max(channels==3)
            counter=counter+1;
            raw_array{counter}=raw_b;
        end
    else
        if max(channels==1)
            raw_array=raw_r;
        end
        if max(channels==2)
            raw_array=raw_g;
        end
        if max(channels==3)
            raw_array=raw_b;
        end

    end
else
    disp('unknown raw file')
    disp('unknown raw file')
    disp('unknown raw file')
    disp('unknown raw file')
    disp('unknown raw file')
    disp('unknown raw file')
end
